create definer = root@`%` trigger user_insert
    after insert
    on user
    for each row
BEGIN

    DECLARE roleId INT;

	SET roleId = (SELECT role_id FROM role WHERE role_name ='顾客');

		INSERT user_role VALUES(new.user_id,roleId);

END;

